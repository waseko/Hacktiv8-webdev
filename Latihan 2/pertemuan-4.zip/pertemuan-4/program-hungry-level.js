let full_level = 0;

while(full_level < 5) {
    console.log(full_level);
    full_level = full_level + 1; 
    // atau full_level += 1;
    // atau full_level++
}

console.log("Saya kenyang...");
console.log("Full Level = " + full_level);
